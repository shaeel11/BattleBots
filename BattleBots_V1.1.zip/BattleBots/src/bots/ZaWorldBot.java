package bots;

import java.awt.Graphics;
import java.awt.Image;

import arena.BattleBotArena;
import arena.BotInfo;
import arena.Bullet;

public class ZaWorldBot extends Bot {
	
	/* ZaWorldBot V1.1 (To Do's)
	 * Attempt to make the Bots dodge bullets
	 * Attempt to add Image on Bot
	*/
	
	Image up, down, left, right, current; //images
	private int move = BattleBotArena.UP;
	BotHelper helper = new BotHelper(); //instance caller

	public ZaWorldBot() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void newRound() {
		// TODO Auto-generated method stub

	}

	@Override
	public int getMove(BotInfo me, boolean shotOK, BotInfo[] liveBots, BotInfo[] deadBots, Bullet[] bullets) {

		//find closest Enemy
		BotInfo closestEnemy =  helper.findClosest(me, liveBots);
		
		//find closest Bullet
		Bullet closestDanger = helper.findClosest(me, bullets);
		
		//find closest DeadBot
		BotInfo closestDead = helper.findClosest(me,  deadBots);
		
		//Find the nearest bullet that is moving towards me
		//To find if it's heading towards me find the acceleration direction
		//Dodge the Bullet
		
		
		/*if(closestDead.getBulletsLeft() == 0) {
			closestDead.
		}*/
				
		
		return 0;
	}
	
	//make method to find acceleration's direction of the Object 
	public double findAcceleration() {
		return 0;
	}
	
	public void draw(Graphics g, int x, int y) {
		g.drawImage(current, x, y, Bot.RADIUS*2, Bot.RADIUS*2, null);
	}
	
	public String[] imageNames()
	{
		String[] images = {"roomba_up.png","roomba_down.png","roomba_left.png","roomba_right.png"};
		return images;
	}

	/**
	 * Store the loaded images
	 */
	public void loadedImages(Image[] images)
	{
		if (images != null)
		{
			current = up = images[0];
			down = images[1];
			left = images[2];
			right = images[3];
		}
	}
	
	public void newRound() {
		int i = (int)(Math.random()*4);
		if (i==0)
		{
			move = BattleBotArena.UP;
			current = up;
		}
		else if (i==1)
		{
			move = BattleBotArena.DOWN;
			current = down;
		}
		else if (i==2)
		{
			move = BattleBotArena.LEFT;
			current = left;
		}
		else
		{
			move = BattleBotArena.RIGHT;
			current = right;
		}

	}
	
	@Override
	public void draw(Graphics g, int x, int y) {
		// TODO Auto-generated method stub
		g.drawImage(current, x, y, Bot.RADIUS*2, Bot.RADIUS*2, null);
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTeamName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String outgoingMessage() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void incomingMessage(int botNum, String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public String[] imageNames() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void loadedImages(Image[] images) {
		// TODO Auto-generated method stub

	}

}
