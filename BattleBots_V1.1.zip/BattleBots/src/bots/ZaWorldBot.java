package bots;

import java.awt.Graphics;
import java.awt.Image;

import arena.BotInfo;
import arena.Bullet;

public class ZaWorldBot extends Bot {
	
	/* ZaWorldBot V1.1 (To Do's)
	 * Attempt to make the Bots dodge bullets
	*/
	
	
	BotHelper helper = new BotHelper();

	public ZaWorldBot() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void newRound() {
		// TODO Auto-generated method stub

	}

	@Override
	public int getMove(BotInfo me, boolean shotOK, BotInfo[] liveBots, BotInfo[] deadBots, Bullet[] bullets) {

		//find closest Enemy
		BotInfo closestEnemy =  helper.findClosest(me, liveBots);
		
		//find closest Bullet
		Bullet closestDanger = helper.findClosest(me, bullets);
		
		//find closest DeadBot
		BotInfo closestDead = helper.findClosest(me,  deadBots);
		
		//Find the nearest bullet that is moving towards me
		//To find if it's heading towards me find the acceleration direction
		//Dodge the Bullet
		
		
		/*if(closestDead.getBulletsLeft() == 0) {
			closestDead.
		}*/
				
		
		return 0;
	}
	
	//make method to find acceleration's direction of the Object 

	@Override
	public void draw(Graphics g, int x, int y) {
		// TODO Auto-generated method stub

	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTeamName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String outgoingMessage() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void incomingMessage(int botNum, String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public String[] imageNames() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void loadedImages(Image[] images) {
		// TODO Auto-generated method stub

	}

}
