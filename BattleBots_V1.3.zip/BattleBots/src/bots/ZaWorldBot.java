package bots;

import java.awt.Graphics;
import java.awt.Image;

import arena.BattleBotArena;
import arena.BotInfo;
import arena.Bullet;

public class ZaWorldBot extends Bot {

	/*
	 * ZaWorldBot V1.1 (To Do's & Done) 
	 * Attempt to make the Bots dodge bullets 
	 * Attempt to add Image on Bot 
	 * ZaWorldBot V1.2 (To Do's & Done) 
	 * Gave up on Image on bot for now...
	 * Attempt to dodge bullets from finding acceleration Note: Better not to use time but instead to find speed and displacement to find enemy bullets
	 * ZaWorldBot V1.3 (To Do's & Done)
	 * Made Image work, need to get a different pic now
	 * Made it move towards enemies and dead bodies
	 * Make it shoot bullets!
	 * Make it dodge bullets!
	 * 
	 */

	double systemTime = System.currentTimeMillis();
	Image up, down, left, right, current; // images
	private int move = BattleBotArena.UP;
	BotHelper helper = new BotHelper(); // instance caller
	BotInfo me;

	public ZaWorldBot() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void newRound() {
		// TODO Auto-generated method stub

	}

	@Override
	public int getMove(BotInfo me, boolean shotOK, BotInfo[] liveBots, BotInfo[] deadBots, Bullet[] bullets) {
		try {
			
			this.me = me;
			
			// make sure bullets exist
			if (bullets.length > 0) {
				// find closest Bullet
				Bullet closestDanger = helper.findClosest(me, bullets);
				// figure out wither it's moving towards you or not
				// if not ignore it
				// if yes, dodge it
				// move to any direction the bullet is not coming from
			}
			
			//closestEnemy 
			BotInfo closestEnemy = helper.findClosest(me, liveBots);
			BotInfo closestDead = helper.findClosest(me, deadBots);
			
			//check to see priority
			if (liveBots.length > 0 || deadBots.length > 0) {
				// find distances of closest Enemy & Dead
				double distDead = helper.calcDistance(me.getX(), me.getY(), closestDead.getX(), closestDead.getY());
				double distEnemy = helper.calcDistance(me.getX(), me.getY(), closestEnemy.getX(), closestEnemy.getY());
				//choose between fighting enemy or getting ammo based on distance.
				//Unless we have none or close to no bullets left
				
				//focus alive
				if (distEnemy <= distDead && me.getBulletsLeft() > 5 || me.getBulletsLeft() > 5) {
					//displacement of horizontal distance
					double horizDist = helper.calcDisplacement(me.getX(), closestEnemy.getX());
					//displacement of vertical distance
					double verticDist = helper.calcDisplacement(me.getY(), closestEnemy.getY());
					
					//priorities on distance
					if(horizDist <= verticDist) {
						//Horizontal
						//if on it's on the same X
						if(closestEnemy.getX() == me.getX()) {
							//shoot bullet
						}
						// move left if it's to the left
						if(closestEnemy.getX() < me.getX()) {
							move = BattleBotArena.LEFT;
							current = left;
						} 
						// move right if it's to the right
						else if (closestEnemy.getX() > me.getX()) {
							move = BattleBotArena.RIGHT;
							current = right;
						}
					}
					
					else if(verticDist < horizDist) {
						//Vertical
						//if on it's on the same Y
						if(closestEnemy.getY() == me.getY()) {
							//shoot bullet
						}
						//move upward if it's above
						else if (closestEnemy.getY() < me.getY()) {
							move = BattleBotArena.UP;
							current = up;
						}//move downward if it's below
						else if (closestEnemy.getY() > me.getY()){
							move = BattleBotArena.DOWN;
							current = down;
						}
					}
				}
				//focus dead
				else if (distDead < distEnemy || me.getBulletsLeft() <= 5) {
					
					//Horizontal
					// move left if it's to the left
					if(closestDead.getX() < me.getX()) {
						move = BattleBotArena.LEFT;
						current = left;
					} 
					// move right if it's to the right
					else if (closestDead.getX() > me.getX()) {
						move = BattleBotArena.RIGHT;
						current = right;
					}
					
					//Vertical
					//move upward if it's above
					if (closestDead.getY() < me.getY()) {
						move = BattleBotArena.UP;
						current = up;
					}//move downward if it's below
					else if (closestDead.getY() > me.getY()){
						move = BattleBotArena.DOWN;
						current = down;
					}	
				}
			}

			/* maybe can be used for ignoring dead bodies with no ammo??
			 * if(closestDead.getBulletsLeft() == 0) { closestDead. }
			 */

			/* move = BattleBotArena.UP;

			int i = (int) (Math.random() * 4);
			if (i == 0) {
				move = BattleBotArena.UP;
				current = up;
			} else if (i == 1) {
				move = BattleBotArena.DOWN;
				current = down;
			} else if (i == 2) {
				move = BattleBotArena.LEFT;
				current = left;
			} else {
				move = BattleBotArena.RIGHT;
				current = right;
			} */

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// make method to find acceleration's direction of the Object
	public boolean findAcceleration(Bullet a1) {
		// direction of bullet
		double acceleration;
		// first distance
		double firstPosition = helper.calcDistance(me.getX(), me.getY(), a1.getX(), a1.getY());
		// finding time
		double currentTime = systemTime;
		double timeElapsed = systemTime - currentTime;
		// point at where it is after
		if (timeElapsed >= 0.2) {
			// second distance
			double secondPosition = helper.calcDistance(me.getX(), me.getY(), a1.getX(), a1.getY());
			// find direction
			acceleration = firstPosition - secondPosition;
			// telling direction
			if (acceleration > 0) {
				return true;
			} else {
				return false;
			}
		}

		return true;
	}

	@Override
	public void draw(Graphics g, int x, int y) {
		// TODO Auto-generated method stub
		g.drawImage(current, x, y, Bot.RADIUS * 2, Bot.RADIUS * 2, null);
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTeamName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String outgoingMessage() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void incomingMessage(int botNum, String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public String[] imageNames() {
		// TODO Auto-generated method stub
		String[] images = { "roomba_up.png", "roomba_down.png", "roomba_left.png", "roomba_right.png" };
		return images;
	}

	@Override
	public void loadedImages(Image[] images) {
		// TODO Auto-generated method stub
		if (images != null) {
			current = up = images[0];
			down = images[1];
			left = images[2];
			right = images[3];
		}
	}

}
