package bots;

import java.awt.Graphics;
import java.awt.Image;

import arena.BattleBotArena;
import arena.BotInfo;
import arena.Bullet;

public class ZaWorldBot extends Bot {
	
	/* ZaWorldBot V1.1 (To Do's)
	 * Attempt to make the Bots dodge bullets
	 * Attempt to add Image on Bot
	 * ZaWorldBot V1.2 (To Do's)
	 * Gave up on Image on bot for now...
	 * Attempt to dodge bullets from finding acceleration
	 * Note: Better not to use time but instead to find speed and displacement to find enemy bullets
	*/
	
	double systemTime = System.currentTimeMillis();
	Image up, down, left, right, current; //images
	private int move = BattleBotArena.UP;
	BotHelper helper = new BotHelper(); //instance caller
	BotInfo me;
	
	
	public ZaWorldBot() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void newRound() {
		// TODO Auto-generated method stub

	}

	@Override
	public int getMove(BotInfo me, boolean shotOK, BotInfo[] liveBots, BotInfo[] deadBots, Bullet[] bullets) {
		try {
			
		this.me = me;
		//find closest Enemy
		BotInfo closestEnemy =  helper.findClosest(me, liveBots);
		
		if(bullets.length > 0) {
		//find closest Bullet
		Bullet closestDanger = helper.findClosest(me, bullets);
		}
		
		if(deadBots.length > 0) {
		//find closest DeadBot
		BotInfo closestDead = helper.findClosest(me,  deadBots);
		}
		
		//Find the nearest bullet that is moving towards me
		//To find if it's heading towards me find the acceleration direction
		//Dodge the Bullet
		
		
		/*if(closestDead.getBulletsLeft() == 0) {
			closestDead.
		}*/
		}	
		catch (Exception e) {
			e.printStackTrace();
		}
	return 0;
	}
	
	//make method to find acceleration's direction of the Object 
	public boolean findAcceleration(Bullet a1) {
		//direction of bullet
		double acceleration;
		//first distance
		double firstPosition = helper.calcDistance(me.getX(),me.getY(),a1.getX(),a1.getY());
		//finding time
		double currentTime = systemTime;
		double timeElapsed = systemTime - currentTime;
		//point at where it is after
		if(timeElapsed >= 0.2) {
			//second distance
			double secondPosition = helper.calcDistance(me.getX(),me.getY(),a1.getX(),a1.getY());
			//find direction
			acceleration = firstPosition - secondPosition;
			//telling direction
			if(acceleration > 0) {
				return true;
			} else {
				return false;
			}
		}
		
		
		
		return true;
	}
	
	@Override
	public void draw(Graphics g, int x, int y) {
		// TODO Auto-generated method stub
		g.drawImage(current, x, y, Bot.RADIUS*2, Bot.RADIUS*2, null);
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTeamName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String outgoingMessage() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void incomingMessage(int botNum, String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public String[] imageNames() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void loadedImages(Image[] images) {
		// TODO Auto-generated method stub

	}

}
